typedef int tipoinfo;

typedef struct TNodoA pNodoA;

int verificaARN(pNodoA *a);