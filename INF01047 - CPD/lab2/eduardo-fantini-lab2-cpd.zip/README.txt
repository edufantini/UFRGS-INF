


		Eduardo Fantini - Laboratório 2 - CPD UFRGS 2020
		================================================


[*]	A execução do arquivo se dá da seguinte forma:
	
		./lab2 (endereço do arquivo de entrada)
	
		Por exemplo: ./lab2 entradas/entrada.txt

[*]	Ao fim da execução, serão gerados 4 arquivos de saida e 4 arquivos de stats, como proposto.
