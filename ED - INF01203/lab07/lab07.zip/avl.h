typedef int tipoinfo;

typedef struct TNodoA pNodoA;

int altura(pNodoA *a);
int calcula_fator(pNodoA *a);
int verificaAVL(pNodoA *a);